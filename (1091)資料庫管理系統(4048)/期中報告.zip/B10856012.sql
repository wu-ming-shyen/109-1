-- --------------------------------------------------------
-- 主機:                           127.0.0.1
-- 伺服器版本:                        10.5.5-MariaDB - mariadb.org binary distribution
-- 伺服器作業系統:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 傾印 test 的資料庫結構
CREATE DATABASE IF NOT EXISTS `DB` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `DB`;

-- 傾印  資料表 test.buy 結構
CREATE TABLE IF NOT EXISTS `buy` (
  `B_No` char(10) NOT NULL,
  `P_ID` char(10) NOT NULL,
  `B_method` varchar(20) DEFAULT NULL,
  `B_DateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`B_No`),
  KEY `FK_buy_producer` (`P_ID`),
  CONSTRAINT `FK_buy_producer` FOREIGN KEY (`P_ID`) REFERENCES `producer` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.buy 的資料：~8 rows (近似值)
/*!40000 ALTER TABLE `buy` DISABLE KEYS */;
REPLACE INTO `buy` (`B_No`, `P_ID`, `B_method`, `B_DateTime`) VALUES
	('B000000001', 'P000000001', 'Card', '2020-05-09 17:26:05'),
	('B000000002', 'P000000002', 'Check', '2019-07-16 13:37:05'),
	('B000000003', 'P000000003', 'Cash', '2019-03-22 17:53:44'),
	('B000000004', 'P000000004', 'Check', '2019-11-30 13:43:08'),
	('B000000005', 'P000000005', 'Card', '2020-05-13 23:33:29'),
	('B000000006', 'P000000006', 'Cash', '2020-02-21 10:14:15'),
	('B000000007', 'P000000007', 'Card', '2020-09-04 14:45:05'),
	('B000000008', 'P000000008', 'Check', '2020-04-22 19:19:01'),
	('B000000009', 'P000000009', 'Cash', '2019-10-12 11:56:12'),
	('B000000010', 'P000000010', 'Card', '2020-03-18 23:37:14');
/*!40000 ALTER TABLE `buy` ENABLE KEYS */;

-- 傾印  資料表 test.buy_records 結構
CREATE TABLE IF NOT EXISTS `buy_records` (
  `Pro_No` char(10) NOT NULL DEFAULT '',
  `B_No` char(10) NOT NULL DEFAULT '',
  `B_Price` float(12,2) DEFAULT 0.00,
  PRIMARY KEY (`Pro_No`,`B_No`),
  KEY `FK_buy_records_buy` (`B_No`),
  CONSTRAINT `FK_buy_records_buy` FOREIGN KEY (`B_No`) REFERENCES `buy` (`B_No`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_buy_records_product` FOREIGN KEY (`Pro_No`) REFERENCES `product` (`Pro_No`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.buy_records 的資料：~9 rows (近似值)
/*!40000 ALTER TABLE `buy_records` DISABLE KEYS */;
REPLACE INTO `buy_records` (`Pro_No`, `B_No`, `B_Price`) VALUES
	('PD00000001', 'B000000001', 10000.00),
	('PD00000002', 'B000000002', 20000.00),
	('PD00000003', 'B000000003', 9000.00),
	('PD00000004', 'B000000004', 5000.00),
	('PD00000005', 'B000000005', 17000.00),
	('PD00000006', 'B000000006', 22000.00),
	('PD00000007', 'B000000007', 12000.00),
	('PD00000008', 'B000000008', 15000.00),
	('PD00000009', 'B000000009', 25000.00),
	('PD00000010', 'B000000010', 3000.00);
/*!40000 ALTER TABLE `buy_records` ENABLE KEYS */;

-- 傾印  資料表 test.consumer 結構
CREATE TABLE IF NOT EXISTS `consumer` (
  `C_ID` char(10) NOT NULL,
  `C_Name` varchar(20) DEFAULT NULL,
  `C_Gender` char(10) DEFAULT NULL,
  `C_Birthday` date DEFAULT NULL,
  `C_Age` int(12) DEFAULT NULL,
  PRIMARY KEY (`C_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.consumer 的資料：~8 rows (近似值)
/*!40000 ALTER TABLE `consumer` DISABLE KEYS */;
REPLACE INTO `consumer` (`C_ID`, `C_Name`, `C_Gender`, `C_Birthday`, `C_Age`) VALUES
	('C000000001', '張昌辛', 'Female', '2004-08-01', 16),
	('C000000002', '盧維綺', 'Female', '1948-01-31', 72),
	('C000000003', '林政達', 'Male', '1966-05-09', 54),
	('C000000004', '杜宇軒', 'Male', '1956-03-11', 64),
	('C000000005', '林琪珠', 'Female', '1972-07-29', 48),
	('C000000006', '林淑芬', 'Female', '1932-10-08', 88),
	('C000000007', '王宛齊', 'Male', '1961-05-14', 59),
	('C000000008', '張嘉娥', 'Female', '1927-07-03', 93),
	('C000000009', '李宜臻', 'Female', '1985-09-26', 35),
	('C000000010', '毛浩珍', 'Female', '1946-06-29', 74);
/*!40000 ALTER TABLE `consumer` ENABLE KEYS */;

-- 傾印  資料表 test.consumer_ email 結構
CREATE TABLE IF NOT EXISTS `consumer_ email` (
  `C_ID` char(10) NOT NULL,
  `C_ Email` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`C_ID`,`C_ Email`),
  CONSTRAINT `FK_consumer_ email_consumer` FOREIGN KEY (`C_ID`) REFERENCES `consumer` (`C_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.consumer_ email 的資料：~9 rows (近似值)
/*!40000 ALTER TABLE `consumer_ email` DISABLE KEYS */;
REPLACE INTO `consumer_ email` (`C_ID`, `C_ Email`) VALUES
	('C000000001', 'Hart@gmail.com'),
	('C000000002', 'Garcia@gmail.com'),
	('C000000003', 'Stanford@gmail.com'),
	('C000000004', 'Abbadie@gmail.com'),
	('C000000006', 'Harris@gmail.com'),
	('C000000007', 'Michaels@gmail.com'),
	('C000000008', 'BARNES@gmail.com'),
	('C000000009', 'KOCH@gmail.com'),
	('C000000010', 'MAXWELL@gmail.com');
/*!40000 ALTER TABLE `consumer_ email` ENABLE KEYS */;

-- 傾印  資料表 test.consumer_ phone 結構
CREATE TABLE IF NOT EXISTS `consumer_ phone` (
  `C_ID` char(10) NOT NULL,
  `C_ Phone` char(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`C_ID`,`C_ Phone`),
  CONSTRAINT `FK_consumer_ phone_consumer` FOREIGN KEY (`C_ID`) REFERENCES `consumer` (`C_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.consumer_ phone 的資料：~8 rows (近似值)
/*!40000 ALTER TABLE `consumer_ phone` DISABLE KEYS */;
REPLACE INTO `consumer_ phone` (`C_ID`, `C_ Phone`) VALUES
	('C000000001', '0914662595'),
	('C000000002', '0931662983'),
	('C000000003', '0921026195'),
	('C000000004', '0953562444'),
	('C000000005', '0982601348'),
	('C000000006', '0929053560'),
	('C000000007', '0922802191'),
	('C000000008', '0960812140'),
	('C000000009', '0920384554'),
	('C000000010', '0911892046');
/*!40000 ALTER TABLE `consumer_ phone` ENABLE KEYS */;

-- 傾印  資料表 test.employee 結構
CREATE TABLE IF NOT EXISTS `employee` (
  `E_ID` char(10) NOT NULL,
  `E_Name` char(10) NOT NULL,
  `E_Gender` char(10) DEFAULT NULL,
  `E_Birthday` date DEFAULT NULL,
  `E_salary` float(12,2) DEFAULT NULL,
  `E_Address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`E_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.employee 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
REPLACE INTO `employee` (`E_ID`, `E_Name`, `E_Gender`, `E_Birthday`, `E_salary`, `E_Address`) VALUES
	('E000000001', '劉佩珊', 'Female', '1967-09-05', 22000.00, '嘉義縣溪口鄉南澳街870巷519號96樓'),
	('E000000002', '李宇翔', 'Male', '1998-09-14', 22000.00, '花蓮縣萬榮鄉永榮二街八段363號42樓'),
	('E000000003', '陳偉智', 'Male', '1992-02-11', 22000.00, '臺中市東勢區水美街855巷243號'),
	('E000000004', '吳韋伶', 'Female', '1978-05-29', 50000.00, '金門縣金寧鄉全福路951巷803號'),
	('E000000005', '張書士', 'Male', '1964-07-03', 50000.00, '連江縣南竿鄉新寮一路925巷361弄422號'),
	('E000000006', '吳文源', 'Male', '1972-12-03', 22000.00, '彰化縣芬園鄉自強九路303巷4號21樓'),
	('E000000007', '盧俊杰', 'Male', '1958-05-31', 22000.00, '苗栗縣大湖鄉公館村東平街211巷609弄741號'),
	('E000000008', '李子軒', 'Female', '1966-09-27', 50000.00, '桃園市平鎮區頂湖五路487巷407弄370號83樓'),
	('E000000009', '郭俊諺', 'Male', '1986-08-16', 100000.00, '嘉義市東區環山九如路337號12樓'),
	('E000000010', '羅曉睿', 'Male', '1974-07-08', 100000.00, '臺北市松山區復華四路210號');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;

-- 傾印  資料表 test.employee _email 結構
CREATE TABLE IF NOT EXISTS `employee _email` (
  `E_ID` char(10) NOT NULL,
  `E_Email` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`E_ID`,`E_Email`),
  CONSTRAINT `FK_employee _email_employee` FOREIGN KEY (`E_ID`) REFERENCES `employee` (`E_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.employee _email 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `employee _email` DISABLE KEYS */;
REPLACE INTO `employee _email` (`E_ID`, `E_Email`) VALUES
	('E000000001', 'Durever39@gmail.com'),
	('E000000002', 'uDknEv7U@gmail.com'),
	('E000000003', '5b4H6TAs@gmail.com'),
	('E000000004', '9tnP5sm5@gmail.com'),
	('E000000005', 'x2vU3qSC@gmail.com'),
	('E000000006', 'TFmvdZgY@gmail.com'),
	('E000000007', 'udyFmvQQ@gmail.com'),
	('E000000008', 'uh9p6UGG@gmail.com'),
	('E000000009', '6vwcAdqM@gmail.com'),
	('E000000010', 'SwvmBC2X@gmail.com');
/*!40000 ALTER TABLE `employee _email` ENABLE KEYS */;

-- 傾印  資料表 test.employee _phone 結構
CREATE TABLE IF NOT EXISTS `employee _phone` (
  `E_ID` char(10) NOT NULL,
  `E_Phone` char(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`E_ID`,`E_Phone`),
  CONSTRAINT `FK_employee _phone_employee` FOREIGN KEY (`E_ID`) REFERENCES `employee` (`E_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.employee _phone 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `employee _phone` DISABLE KEYS */;
REPLACE INTO `employee _phone` (`E_ID`, `E_Phone`) VALUES
	('E000000001', '0954288437'),
	('E000000002', '0929751186'),
	('E000000003', '0968802732'),
	('E000000004', '0986368974'),
	('E000000005', '0982054038'),
	('E000000006', '0931729087'),
	('E000000007', '0954874730'),
	('E000000008', '0933501963'),
	('E000000009', '0926182463'),
	('E000000010', '0952414544');
/*!40000 ALTER TABLE `employee _phone` ENABLE KEYS */;

-- 傾印  資料表 test.order 結構
CREATE TABLE IF NOT EXISTS `order` (
  `O_DateTime` datetime NOT NULL,
  `S_No` char(10) DEFAULT NULL,
  `O_Cost` float(12,2) DEFAULT 0.00,
  PRIMARY KEY (`O_DateTime`) USING BTREE,
  KEY `FK_order_sell` (`S_No`),
  CONSTRAINT `FK_order_sell` FOREIGN KEY (`S_No`) REFERENCES `sell` (`S_No`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.order 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
REPLACE INTO `order` (`O_DateTime`, `S_No`, `O_Cost`) VALUES
	('2019-03-31 17:02:04', 'S000000001', 10.00),
	('2019-07-22 18:39:31', 'S000000003', 210.00),
	('2019-09-06 08:01:44', 'S000000005', 300.00),
	('2019-09-06 08:49:33', 'S000000007', 900.00),
	('2019-12-02 04:35:10', 'S000000009', 180.00),
	('2019-12-16 15:27:48', 'S000000002', 50.00),
	('2020-03-24 09:54:13', 'S000000004', 100.00),
	('2020-05-29 04:48:25', 'S000000006', 80.00),
	('2020-07-16 00:18:27', 'S000000008', 40.00),
	('2020-09-10 18:25:49', 'S000000010', 60.00);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;

-- 傾印  資料表 test.oredrs 結構
CREATE TABLE IF NOT EXISTS `oredrs` (
  `Pro_No` char(10) NOT NULL,
  `O_DateTime` datetime NOT NULL,
  `Amount` int(11) DEFAULT 0,
  PRIMARY KEY (`Pro_No`,`O_DateTime`),
  KEY `FK_oredrs_order` (`O_DateTime`),
  CONSTRAINT `FK_oredrs_order` FOREIGN KEY (`O_DateTime`) REFERENCES `order` (`O_DateTime`),
  CONSTRAINT `FK_oredrs_product` FOREIGN KEY (`Pro_No`) REFERENCES `product` (`Pro_No`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.oredrs 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `oredrs` DISABLE KEYS */;
REPLACE INTO `oredrs` (`Pro_No`, `O_DateTime`, `Amount`) VALUES
	('PD00000001', '2019-03-31 17:02:04', 1),
	('PD00000002', '2019-12-16 15:27:48', 1),
	('PD00000003', '2020-05-29 04:48:25', 1),
	('PD00000004', '2020-07-16 00:18:27', 1),
	('PD00000005', '2020-09-10 18:25:49', 1),
	('PD00000006', '2019-07-22 18:39:31', 3),
	('PD00000007', '2019-09-06 08:01:44', 5),
	('PD00000008', '2019-09-06 08:49:33', 10),
	('PD00000009', '2019-12-02 04:35:10', 6),
	('PD00000010', '2020-03-24 09:54:13', 1);
/*!40000 ALTER TABLE `oredrs` ENABLE KEYS */;

-- 傾印  資料表 test.producer 結構
CREATE TABLE IF NOT EXISTS `producer` (
  `P_ID` char(10) NOT NULL,
  `P_Name` varchar(20) NOT NULL,
  `P_Gender` char(10) DEFAULT NULL,
  `P_Birthday` date DEFAULT NULL,
  `P_Age` int(12) DEFAULT NULL,
  PRIMARY KEY (`P_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.producer 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `producer` DISABLE KEYS */;
REPLACE INTO `producer` (`P_ID`, `P_Name`, `P_Gender`, `P_Birthday`, `P_Age`) VALUES
	('P000000001', '陳盈君', 'Female', '1991-01-11', 29),
	('P000000002', '楊淑娟', 'Female', '1969-09-06', 51),
	('P000000003', '林舒婷', 'Female', '1970-10-06', 50),
	('P000000004', '汪敏軍', 'Male', '1989-09-12', 31),
	('P000000005', '李建中', 'Male', '1987-03-03', 33),
	('P000000006', '張怡君', 'Female', '1992-10-31', 28),
	('P000000007', '黃明群', 'Male', '1952-02-15', 68),
	('P000000008', '李建志', 'Male', '1996-08-07', 24),
	('P000000009', '黃雅雯', 'Female', '1997-08-12', 23),
	('P000000010', '馬志凌', 'Female', '1982-04-30', 38);
/*!40000 ALTER TABLE `producer` ENABLE KEYS */;

-- 傾印  資料表 test.producer_ email 結構
CREATE TABLE IF NOT EXISTS `producer_ email` (
  `P_ID` char(10) NOT NULL,
  `P_ Email` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`P_ID`,`P_ Email`),
  CONSTRAINT `FK_producer_ email_producer` FOREIGN KEY (`P_ID`) REFERENCES `producer` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.producer_ email 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `producer_ email` DISABLE KEYS */;
REPLACE INTO `producer_ email` (`P_ID`, `P_ Email`) VALUES
	('P000000001', 'Abraham1@gmail.com'),
	('P000000002', 'Winnie8971@gmail.com'),
	('P000000003', 'Gene164@gmail.com'),
	('P000000004', 'Milton1254@gmail.com'),
	('P000000005', 'Babs5779@gmail.com'),
	('P000000006', 'Dot54@gmail.com'),
	('P000000007', 'Ashley57@gmail.com'),
	('P000000008', 'Laura46@gmail.com'),
	('P000000009', 'Millie8774@gmail.com'),
	('P000000010', 'Nita5147@gmail.com');
/*!40000 ALTER TABLE `producer_ email` ENABLE KEYS */;

-- 傾印  資料表 test.producer_ phone 結構
CREATE TABLE IF NOT EXISTS `producer_ phone` (
  `P_ID` char(10) NOT NULL,
  `P_ Phone` char(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`P_ID`,`P_ Phone`),
  CONSTRAINT `FK_producer_ phone_producer` FOREIGN KEY (`P_ID`) REFERENCES `producer` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.producer_ phone 的資料：~9 rows (近似值)
/*!40000 ALTER TABLE `producer_ phone` DISABLE KEYS */;
REPLACE INTO `producer_ phone` (`P_ID`, `P_ Phone`) VALUES
	('P000000001', '0953278877'),
	('P000000002', '0932819573'),
	('P000000003', '0955887196'),
	('P000000004', '0931581474'),
	('P000000005', '0989739589'),
	('P000000006', '0916575038'),
	('P000000007', '0938056983'),
	('P000000008', '0987830997'),
	('P000000009', '0958718958'),
	('P000000010', '0968594156');
/*!40000 ALTER TABLE `producer_ phone` ENABLE KEYS */;

-- 傾印  資料表 test.product 結構
CREATE TABLE IF NOT EXISTS `product` (
  `Pro_No` char(10) NOT NULL,
  `E_ID` char(10) NOT NULL,
  `Pro_Name` varchar(20) DEFAULT NULL,
  `Pro_Producer` char(10) DEFAULT NULL,
  `Pro_Category` varchar(20) DEFAULT NULL,
  `Pro_UnitPrice` float(12,2) DEFAULT NULL,
  PRIMARY KEY (`Pro_No`),
  KEY `FK_product_employee` (`E_ID`),
  KEY `FK_product_producer` (`Pro_Producer`) USING BTREE,
  CONSTRAINT `FK_product_employee` FOREIGN KEY (`E_ID`) REFERENCES `employee` (`E_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_product_producer` FOREIGN KEY (`Pro_Producer`) REFERENCES `producer` (`P_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.product 的資料：~20 rows (近似值)
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
REPLACE INTO `product` (`Pro_No`, `E_ID`, `Pro_Name`, `Pro_Producer`, `Pro_Category`, `Pro_UnitPrice`) VALUES
	('PD00000001', 'E000000001', '檸檬', 'P000000001', '水果類', 10.00),
	('PD00000002', 'E000000001', '芒果', 'P000000001', '水果類', 50.00),
	('PD00000003', 'E000000002', '鳳梨', 'P000000002', '水果類', 80.00),
	('PD00000004', 'E000000002', '芭樂', 'P000000002', '水果類', 40.00),
	('PD00000005', 'E000000003', '黃金果', 'P000000003', '水果類', 60.00),
	('PD00000006', 'E000000003', '奇異果', 'P000000003', '水果類', 70.00),
	('PD00000007', 'E000000004', '酪梨', 'P000000004', '水果類', 60.00),
	('PD00000008', 'E000000004', '柚子', 'P000000004', '水果類', 90.00),
	('PD00000009', 'E000000005', '杏鮑菇', 'P000000005', '菇菌類', 30.00),
	('PD00000010', 'E000000005', '松茸', 'P000000005', '菇菌類', 100.00),
	('PD00000011', 'E000000006', '洛神花', 'P000000006', '花果菜類', 100.00),
	('PD00000012', 'E000000007', '萵苣菜', 'P000000006', '葉菜類', 30.00),
	('PD00000013', 'E000000007', '芥藍菜', 'P000000007', '葉菜類', 20.00),
	('PD00000014', 'E000000007', '九層塔', 'P000000007', '葉菜類', 20.00),
	('PD00000015', 'E000000008', '胡蘿蔔', 'P000000008', '根莖菜類', 35.00),
	('PD00000016', 'E000000008', '馬鈴薯', 'P000000008', '根莖菜類', 60.00),
	('PD00000017', 'E000000009', '洋蔥', 'P000000009', '根莖菜類', 50.00),
	('PD00000018', 'E000000009', '大蒜', 'P000000009', '根莖菜類', 70.00),
	('PD00000019', 'E000000010', '苦瓜', 'P000000010', '花果菜類', 120.00),
	('PD00000020', 'E000000010', '茄子', 'P000000010', '花果菜類', 85.00);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;

-- 傾印  資料表 test.sell 結構
CREATE TABLE IF NOT EXISTS `sell` (
  `S_No` char(10) NOT NULL,
  `C_ID` char(10) NOT NULL,
  `S_method` varchar(20) DEFAULT NULL,
  `S_DateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`S_No`),
  KEY `FK_sell_consumer` (`C_ID`),
  CONSTRAINT `FK_sell_consumer` FOREIGN KEY (`C_ID`) REFERENCES `consumer` (`C_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.sell 的資料：~8 rows (近似值)
/*!40000 ALTER TABLE `sell` DISABLE KEYS */;
REPLACE INTO `sell` (`S_No`, `C_ID`, `S_method`, `S_DateTime`) VALUES
	('S000000001', 'C000000001', 'Cash', '2019-10-21 00:53:01'),
	('S000000002', 'C000000002', 'LINE Pay', '2019-03-28 07:28:05'),
	('S000000003', 'C000000003', 'Cash', '2019-11-29 10:31:00'),
	('S000000004', 'C000000004', 'Cash', '2019-04-11 17:25:15'),
	('S000000005', 'C000000005', 'LINE Pay', '2019-11-16 17:30:31'),
	('S000000006', 'C000000006', 'Card', '2019-08-23 22:20:56'),
	('S000000007', 'C000000007', 'Cash', '2020-06-27 17:39:14'),
	('S000000008', 'C000000008', 'Card', '2019-01-31 06:03:51'),
	('S000000009', 'C000000009', 'Card', '2020-05-29 21:55:35'),
	('S000000010', 'C000000010', 'LINE Pay', '2020-03-30 14:17:17');
/*!40000 ALTER TABLE `sell` ENABLE KEYS */;

-- 傾印  資料表 test.stor 結構
CREATE TABLE IF NOT EXISTS `stor` (
  `Sto_Num` char(10) NOT NULL,
  `Pro_No` char(10) NOT NULL,
  `Sto_Quantity` int(12) NOT NULL,
  `Sto_Category` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Sto_Num`),
  KEY `FK_stor_product` (`Pro_No`),
  CONSTRAINT `FK_stor_product` FOREIGN KEY (`Pro_No`) REFERENCES `product` (`Pro_No`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在傾印表格  test.stor 的資料：~10 rows (近似值)
/*!40000 ALTER TABLE `stor` DISABLE KEYS */;
REPLACE INTO `stor` (`Sto_Num`, `Pro_No`, `Sto_Quantity`, `Sto_Category`) VALUES
	('ST00000001', 'PD00000001', 50, '水果類'),
	('ST00000002', 'PD00000002', 100, '水果類'),
	('ST00000003', 'PD00000003', 150, '水果類'),
	('ST00000004', 'PD00000004', 200, '水果類'),
	('ST00000005', 'PD00000005', 150, '水果類'),
	('ST00000006', 'PD00000006', 200, '水果類'),
	('ST00000007', 'PD00000007', 300, '水果類'),
	('ST00000008', 'PD00000008', 100, '水果類'),
	('ST00000009', 'PD00000009', 50, '菇菌類'),
	('ST00000010', 'PD00000010', 200, '菇菌類');
/*!40000 ALTER TABLE `stor` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
