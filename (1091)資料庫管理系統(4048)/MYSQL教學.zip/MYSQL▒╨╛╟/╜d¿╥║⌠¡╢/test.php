<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>範例網頁</title>
    <!-- jquery CDN  -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
    <!-- /jquery CDN -->
</head>
<style>
table,
td {
    border: 1px solid #333;
}

thead,
tfoot {
    background-color: #333;
    color: #fff;
}

</style>
<body>

<table width="1000px">
    <thead>
        <tr>
            <th colspan="7">測試表格</th>
        </tr>
        <tr>
            <td>編號</td>
            <td>姓名</td>
            <td>性別</td>
            <td>電話</td>
            <td>時間</td>
        </tr>
    </thead>
    <tbody id="test">
    </tbody>
</table>
<p>
<label>新增</label><br>

<label>姓名:</label>
<input id="add_name" type="text">

<label>性別:</label>
<select id="add_gender">
    <option value="男">男</option>
    <option value="女">女</option>
</select>

<label>電話:</label>
<input id="add_phone" type="text">

<button id="add">新增</button>
<p>
<label>修改</label><br>
<label>編號:</label>
<input id="edit_id" type="text">

<label>姓名:</label>
<input id="edit_name" type="text">

<label>性別:</label>
<select id="edit_gender">
    <option value="男">男</option>
    <option value="女">女</option>
</select>

<label>電話:</label>
<input id="edit_phone" type="text">

<button id="update">修改</button>
<p>
<label>刪除</label><br>

<label>編號:</label>
<input id="delete_id" type="text">

<button id="delete">刪除</button>

</body>

<script>
//表格資料region
$.ajax({
    url: "database/select.php",
    type: "POST",
    dataType: "JSON",
    success: function (data) {
        var cssString = "";
        for (var index in data.id) {
            cssString += 
                    '<tr>' +
                    '<td>' + data.id[index] + '</td>' +
                    '<td>' + data.name[index] + '</td>' +
                    '<td>' + data.gender[index] + '</td>' +
                    '<td>' + data.phone[index] + '</td>' +
                    '<td>' + data.time[index] + '</td>' +
                    '</tr>'
        } 
        $("#test").html(cssString);
    },
    error: function (e) {
            notyf.alert('伺服器錯誤,無法載入' + e);
     }
});
//endregion
    
//新增按鈕region
$( "#add" ).click(function() {
    $.ajax({
        type: "POST",
        url: "database/add.php",
        data: {
            name:$("#add_name").val(),
            gender:$("#add_gender").val(),
            phone:$("#add_phone").val(),
        }, // serializes the form's elements.
        success: function(data)
        {   
//               console.log(data);
            if(data == 1){
                alert("新增成功!");
                window.location.replace("test.php");   
            }else{
                alert("新增失敗!");
                window.location.replace("test.php");  
            }       
        },
        error:function(){
            alert("404!");
        }
        
    });
});
//endregion
    
//更新按鈕region
$( "#update" ).click(function() {
    $.ajax({
        type: "POST",
        url: "database/update.php",
        data: {
            id:$("#edit_id").val(),
            name:$("#edit_name").val(),
            gender:$("#edit_gender").val(),
            phone:$("#edit_phone").val(),
        }, // serializes the form's elements.
        success: function(data)
        {   
//               console.log(data);
            if(data == 1){
                alert("修改成功!");
                window.location.replace("test.php");   
            }else{
                alert("修改失敗!");
                window.location.replace("test.php");  
            }       
        },
        error:function(){
            alert("404!");
        }
        
    });
});
//endregion
    
//刪除按鈕region
$( "#delete" ).click(function() {
    $.ajax({
        type: "POST",
        url: "database/delete.php",
        data: {
            id:$("#delete_id").val(),
        }, // serializes the form's elements.
        success: function(data)
        {   
//               console.log(data);
            if(data == 1){
                alert("刪除成功!");
                window.location.replace("test.php");   
            }else{
                alert("刪除失敗!");
                window.location.replace("test.php");  
            }       
        },
        error:function(){
            alert("404!");
        }
        
    });
});
//endregion
</script>
</html>