<?php
include("sql_connect.php");//連接資料庫
$id = $_POST["id"];
//region 日誌記錄
$delete = "DELETE FROM `test1` WHERE `test1`.`id` = $id";
if(mysqli_query($conn,$delete)){
        echo true;
    }else{
        echo false;
    }
//endregion
  mysqli_close($conn);
?>
