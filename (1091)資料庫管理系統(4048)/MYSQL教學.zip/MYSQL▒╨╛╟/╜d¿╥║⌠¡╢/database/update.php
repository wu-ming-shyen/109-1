<?php
include("sql_connect.php");//連接資料庫
$id = $_POST['id'];
$name = $_POST['name'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];

$note_update = "UPDATE `test1` SET `name` = '$name', `gender` = '$gender', `phone` = '$phone' WHERE `test1`.`id` = $id";
if(mysqli_query($conn,$note_update)){
        echo true;
    }else{
        echo false;
    }

mysqli_close($conn);
?>
