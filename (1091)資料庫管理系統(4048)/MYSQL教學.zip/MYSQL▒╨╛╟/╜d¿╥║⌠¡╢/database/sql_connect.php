<?php
//資料庫設定
//資料庫位置
$servername = "localhost";//本地或IP位置
$username = "test";//帳號
$password = "1105";//密碼
$dbname = "test";//要連接的資料庫
$dbport = "3306";//Port號

//對資料庫連線
$conn=mysqli_connect($servername, $username, $password, $dbname, $dbport);
if(!@mysqli_connect($servername, $username, $password, $dbname, $dbport))
        die("無法對資料庫連線");

//資料庫連線採UTF8
mysqli_query( $conn, "SET NAMES 'utf8'" );

//選擇資料庫
if(!@mysqli_select_db($conn,$dbname))
        die("無法使用資料庫");
?> 