<?php 
include("sql_connect.php"); 
//$member_id =$_SESSION['member_id'];
//region 抓資料
$sql = "SELECT * FROM `test1` ORDER BY `test1`.`time` DESC";
$select_all = mysqli_query($conn,$sql);
$data = array();
$data['id'] = array();
$data['name'] = array();
$data['gender'] = array();
$data['phone'] = array();
$data['time'] = array();


for($i=1; $i <= mysqli_num_rows($select_all);$i++){
    $text = mysqli_fetch_row($select_all);
    array_push($data['id'], $text[0]);
    array_push($data['name'], $text[1]);
    array_push($data['gender'], $text[2]);
    array_push($data['phone'], $text[3]);
    array_push($data['time'], $text[4]);
}
  mysqli_close($conn);
  echo json_encode($data);
//endregion
?>