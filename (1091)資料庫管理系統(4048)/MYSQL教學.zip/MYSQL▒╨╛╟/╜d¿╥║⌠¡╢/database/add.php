<?php
include("sql_connect.php");//連接資料庫
$name = $_POST['name'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];

$ins = "INSERT INTO `test1` (`name`, `gender`, `phone`) VALUES ('$name', '$gender', '$phone')"; //新增資料,
if(mysqli_query($conn,$ins)){
    echo true;
}else{
    echo false;
}

  mysqli_close($conn);
 ?>