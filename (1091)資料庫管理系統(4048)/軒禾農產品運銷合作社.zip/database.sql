-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 2021-01-13 06:06:29
-- 伺服器版本： 10.4.17-MariaDB
-- PHP 版本： 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `database`
--

-- --------------------------------------------------------

--
-- 資料表結構 `buy`
--

CREATE TABLE `buy` (
  `B_No` int(8) NOT NULL,
  `P_ID` int(8) NOT NULL,
  `B_DateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `buy`
--

INSERT INTO `buy` (`B_No`, `P_ID`, `B_DateTime`) VALUES
(1, 1, '2021-01-11 16:03:28'),
(3, 2, '2021-01-12 19:40:09'),
(5, 3, '2021-01-12 19:59:06');

-- --------------------------------------------------------

--
-- 資料表結構 `buy_records`
--

CREATE TABLE `buy_records` (
  `Pro_No` int(8) NOT NULL,
  `B_No` int(8) NOT NULL,
  `B_Price` decimal(8,2) NOT NULL,
  `B_Amount` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `buy_records`
--

INSERT INTO `buy_records` (`Pro_No`, `B_No`, `B_Price`, `B_Amount`) VALUES
(1, 1, '10.00', 1),
(2, 3, '50.00', 2);

-- --------------------------------------------------------

--
-- 資料表結構 `employee`
--

CREATE TABLE `employee` (
  `E_ID` int(8) NOT NULL,
  `E_Name` char(8) NOT NULL,
  `E_Gender` char(4) NOT NULL,
  `E_Phone` char(10) NOT NULL,
  `E_Email` varchar(32) NOT NULL,
  `E_Address` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `employee`
--

INSERT INTO `employee` (`E_ID`, `E_Name`, `E_Gender`, `E_Phone`, `E_Email`, `E_Address`) VALUES
(1, '吳明軒', '男', '0918928733', 'Wu.Ming.Shyen@gmail.com', '台南市東區長榮路二段24巷130號');

-- --------------------------------------------------------

--
-- 資料表結構 `member`
--

CREATE TABLE `member` (
  `M_ID` int(8) NOT NULL,
  `M_Name` char(8) NOT NULL,
  `M_Gender` char(8) NOT NULL,
  `M_Phone` char(10) NOT NULL,
  `M_Email` varchar(32) NOT NULL,
  `M_Address` varchar(32) NOT NULL,
  `M_level` int(2) NOT NULL DEFAULT 1,
  `M_Account` varchar(32) NOT NULL,
  `M_Password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `member`
--

INSERT INTO `member` (`M_ID`, `M_Name`, `M_Gender`, `M_Phone`, `M_Email`, `M_Address`, `M_level`, `M_Account`, `M_Password`) VALUES
(2, '王郁晴', '女', '0916615926', 'QQ@gmail.com', '台中市太平區建興路', 1, 'B10856025', 'B10856025'),
(3, '李舒婷', '女', '0915120609', 'B10856053@mail.npust.edu.tw', '新竹縣建興路', 1, 'B10856053', 'B10856053'),
(6, '吳明軒', '男', '0918928733', 'B10856012@mail.npust.edu.tw', '台南市東區', 1, 'B10856012', 'D123179253');

-- --------------------------------------------------------

--
-- 資料表結構 `producer`
--

CREATE TABLE `producer` (
  `P_ID` int(8) NOT NULL,
  `P_Name` char(8) NOT NULL,
  `P_Gender` char(8) NOT NULL,
  `P_Phone` char(10) NOT NULL,
  `P_Email` varchar(32) NOT NULL,
  `P_Address` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `producer`
--

INSERT INTO `producer` (`P_ID`, `P_Name`, `P_Gender`, `P_Phone`, `P_Email`, `P_Address`) VALUES
(1, '吳明軒', '南', '0918928733', 'B10856025@mail.npust.edu.tw', '台南市東區'),
(2, '王郁晴', '女', '0916615926', 'sunnyqq@gmail.com', '台中市太平區建興路'),
(3, '李舒婷', '女', '0912345678', 'su@gmail.com', '新竹縣'),
(5, '何先生', '男', '0986652353', '', '屏東縣'),
(6, '洪先生', '男', '0945784578', 'fghjkl@gmail.com', '高雄市楠子區'),
(7, '李王小姐', '女', '0915451538', '', '屏東縣萬巒鄉'),
(8, '吳先生', '女', '0916235621', 'djicunkwmm@gmail.com', '台南市安平區');

-- --------------------------------------------------------

--
-- 資料表結構 `product`
--

CREATE TABLE `product` (
  `Pro_No` int(8) NOT NULL,
  `P_ID` int(8) NOT NULL,
  `Pro_Name` varchar(8) NOT NULL,
  `Pro_Category` varchar(8) NOT NULL,
  `Pro_Introduce` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `product`
--

INSERT INTO `product` (`Pro_No`, `P_ID`, `Pro_Name`, `Pro_Category`, `Pro_Introduce`) VALUES
(1, 1, '檸檬', '水果類', '檸檬（學名：Citrus limon）為芸香科柑橘屬的一種，是原產於亞洲[1]的常綠小喬木，其果實為黃色橢圓狀'),
(2, 1, '芒果', '水果類', '芒果（學名：Mangifera indica）也作檬果、杧果、檨；是芒果屬的一種植物和果實。'),
(3, 5, '芭樂', '水果類', '芭樂（學名：Psidium guajava），正寫為「菝仔」，為熱帶、亞熱帶水果，原產美洲'),
(4, 3, '百香果', '水果類', '百香果（學名：Passiflora edulis），又名西番蓮、熱情果、雞蛋果，產於美洲的熱帶及亞熱帶地區'),
(6, 2, '毛豆', '蔬菜類', '毛豆，即未成熟且呈青綠色，作為蔬菜食用的大豆，即全株的鮮莢80%達飽滿時，此時豆莢呈綠色帶有茸毛，故名為「毛豆」，又稱「菜用大豆」。');

-- --------------------------------------------------------

--
-- 資料表結構 `sell`
--

CREATE TABLE `sell` (
  `S_No` int(8) NOT NULL,
  `M_ID` int(8) NOT NULL,
  `S_DateTime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `sell`
--

INSERT INTO `sell` (`S_No`, `M_ID`, `S_DateTime`) VALUES
(1, 3, '2021-01-11 16:03:18'),
(2, 2, '2021-01-12 21:15:38'),
(3, 3, '2021-01-12 21:15:44'),
(6, 3, '2021-01-12 21:15:58');

-- --------------------------------------------------------

--
-- 資料表結構 `sell_records`
--

CREATE TABLE `sell_records` (
  `Pro_No` int(8) NOT NULL,
  `S_No` int(8) NOT NULL,
  `S_Price` decimal(8,2) NOT NULL,
  `Sell_Amount` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `sell_records`
--

INSERT INTO `sell_records` (`Pro_No`, `S_No`, `S_Price`, `Sell_Amount`) VALUES
(1, 1, '10.00', 1);

-- --------------------------------------------------------

--
-- 資料表結構 `stor`
--

CREATE TABLE `stor` (
  `Sto_No` int(8) NOT NULL,
  `Pro_No` int(8) NOT NULL,
  `Sto_Quantity` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `stor`
--

INSERT INTO `stor` (`Sto_No`, `Pro_No`, `Sto_Quantity`) VALUES
(1, 1, 0);

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `buy`
--
ALTER TABLE `buy`
  ADD PRIMARY KEY (`B_No`),
  ADD KEY `P_ID` (`P_ID`);

--
-- 資料表索引 `buy_records`
--
ALTER TABLE `buy_records`
  ADD PRIMARY KEY (`Pro_No`,`B_No`),
  ADD KEY `B_No` (`B_No`),
  ADD KEY `Pro_No` (`Pro_No`);

--
-- 資料表索引 `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`E_ID`);

--
-- 資料表索引 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`M_ID`),
  ADD UNIQUE KEY `M_Account` (`M_Account`);

--
-- 資料表索引 `producer`
--
ALTER TABLE `producer`
  ADD PRIMARY KEY (`P_ID`);

--
-- 資料表索引 `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Pro_No`),
  ADD KEY `P_ID` (`P_ID`);

--
-- 資料表索引 `sell`
--
ALTER TABLE `sell`
  ADD PRIMARY KEY (`S_No`),
  ADD KEY `M_ID` (`M_ID`);

--
-- 資料表索引 `sell_records`
--
ALTER TABLE `sell_records`
  ADD PRIMARY KEY (`Pro_No`,`S_No`),
  ADD KEY `Pro_No` (`Pro_No`),
  ADD KEY `S_No` (`S_No`);

--
-- 資料表索引 `stor`
--
ALTER TABLE `stor`
  ADD PRIMARY KEY (`Sto_No`),
  ADD KEY `Pro_No` (`Pro_No`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `buy`
--
ALTER TABLE `buy`
  MODIFY `B_No` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `employee`
--
ALTER TABLE `employee`
  MODIFY `E_ID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `member`
--
ALTER TABLE `member`
  MODIFY `M_ID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `producer`
--
ALTER TABLE `producer`
  MODIFY `P_ID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `product`
--
ALTER TABLE `product`
  MODIFY `Pro_No` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `sell`
--
ALTER TABLE `sell`
  MODIFY `S_No` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `stor`
--
ALTER TABLE `stor`
  MODIFY `Sto_No` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `buy`
--
ALTER TABLE `buy`
  ADD CONSTRAINT `buy_ibfk_1` FOREIGN KEY (`P_ID`) REFERENCES `producer` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `buy_records`
--
ALTER TABLE `buy_records`
  ADD CONSTRAINT `buy_records_ibfk_1` FOREIGN KEY (`B_No`) REFERENCES `buy` (`B_No`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `buy_records_ibfk_2` FOREIGN KEY (`Pro_No`) REFERENCES `product` (`Pro_No`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`P_ID`) REFERENCES `producer` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `sell`
--
ALTER TABLE `sell`
  ADD CONSTRAINT `sell_ibfk_1` FOREIGN KEY (`M_ID`) REFERENCES `member` (`M_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `sell_records`
--
ALTER TABLE `sell_records`
  ADD CONSTRAINT `sell_records_ibfk_1` FOREIGN KEY (`Pro_No`) REFERENCES `product` (`Pro_No`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sell_records_ibfk_2` FOREIGN KEY (`S_No`) REFERENCES `sell` (`S_No`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的限制式 `stor`
--
ALTER TABLE `stor`
  ADD CONSTRAINT `stor_ibfk_1` FOREIGN KEY (`Pro_No`) REFERENCES `product` (`Pro_No`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
